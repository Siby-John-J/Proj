

module.exports = mainPayment = {}
