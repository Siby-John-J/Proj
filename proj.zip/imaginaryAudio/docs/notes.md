

# TODO

[x] have to add twilio
[x] have to add nodemailer or other email auth

[x] and also add forget password which send a html link
[x] to the email and the password and config password

[+] that you enter there become added to the database
[+] resize the main image to fit the 

have to add all kind of middlewares

# IMPORTENT
pagination is not finished

# in future

need to add ajax for checking the fields, 
need to set middleware in app.js but not on routes [depends on situation]
in setting have to add the theme of double color in which
one was background and other one is content